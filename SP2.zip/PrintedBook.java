package Library;

public class PrintedBook extends Title {
    private final int pages;
    public PrintedBook(String title, String literatureType, int copies, int pages) {
        super(title, literatureType, copies);
        this.pages = pages;
    }
    @Override
    public double calculateRoyalty() {
        double points = pages * calculateLiteraturePoints() * copies;
        return points * rate;
    }
}
