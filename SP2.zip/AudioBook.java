package Library;

public class AudioBook extends Title {
    private final int durationInMinutes;
    public AudioBook(String title, String literatureType, int copies, int durationInMinutes) {
        super(title, literatureType, copies);
        this.durationInMinutes = durationInMinutes;
    }
    @Override
    public double calculateRoyalty() {
        double points = (durationInMinutes * 0.5) * calculateLiteraturePoints() * copies;
        return points * rate;
    }
}