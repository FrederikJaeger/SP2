package Library;

public class LibraryRoyaltyCalculator {
    public static void main(String[] args) {
        Author author = new Author("Klaus Rifbjerg");

        author.addTitle(new PrintedBook("Den kroniske uskyld", "SKØN", 140, 240));
        author.addTitle(new PrintedBook("Amagerdigte", "LYRIK", 50, 14));
        author.addTitle(new PrintedBook("De hellige aber", "BI", 100, 41));
        author.addTitle(new AudioBook("Anna (jeg) Anna", "SKØNA", 70, 491));

        double totalPay = author.calculateTotalPay();
        System.out.printf("%s: %.2fkr\n", author.getName(), totalPay);
    }
}
