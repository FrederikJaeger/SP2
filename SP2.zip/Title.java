package Library;

public class Title {
    protected String title;
    protected String literatureType;
    protected int copies;
    protected double rate = 0.067574;
    public Title(String title, String literatureType, int copies) {
        this.title = title;
        this.literatureType = literatureType;
        this.copies = copies;
    }
    public double calculateRoyalty() {
        return 0;
    }
    protected double calculateLiteraturePoints() {
        return switch (literatureType) {
            case "BI", "TE" -> 3;
            case "LYRIK" -> 6;
            case "SKØN" -> 1.7;
            case "FAG" -> 1;
            case "SKØNA" -> 0.85;
            default -> 1;
        };
    }
}
