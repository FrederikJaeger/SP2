package Library;

import java.util.ArrayList;

public class Author {
    private final String name;
    private final ArrayList<Title> titles;
    public Author(String name) {
        this.name = name;
        this.titles = new ArrayList<>();
    }
    public void addTitle(Title title) {
        titles.add(title);
    }
    public double calculateTotalPay() {
        double totalPay = 0;
        for (Title title : titles) {
            totalPay += title.calculateRoyalty();
        }
        return Math.round(totalPay * 100) / 100.0;
    }
    public String getName() {
        return name;
    }
}
